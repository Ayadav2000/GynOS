
from flask import Blueprint, render_template
from ..models import Patient

patient_bp = Blueprint("patient", __name__)

@patient_bp.route("/patient")
def dashboard():
    return render_template("patient.html")
