
from flask import Blueprint, render_template
from ..models import Patient

doctor_bp = Blueprint("doctor", __name__)

@doctor_bp.route("/doctor")
def dashboard():
    patients = Patient.query.all()
    return render_template("doctor.html", patients=patients)
